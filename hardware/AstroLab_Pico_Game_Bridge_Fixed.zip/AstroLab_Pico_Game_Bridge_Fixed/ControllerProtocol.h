#pragma once
#include <stdint.h>
#include <stddef.h>

// Decodes existing 7-byte ESP32 advertisements and optional 10-byte snapshots.
// Payload: FF FF 'A' 'L' ('1'|'2') ACTION SEQUENCE [forward steer tilt]
struct ControllerPacket {
  uint8_t player, sequence;
  char action;
  bool snapshot;
  int8_t forward, steer, tilt;
};

// Declared in the header so Arduino-generated prototypes know this type.
struct Pending { ControllerPacket packet; uint32_t at; };

inline bool decodeController(const uint8_t* data, size_t size, ControllerPacket& out) {
  if (!data || (size != 7 && size != 10) ||
      data[0] != 0xFF || data[1] != 0xFF ||
      data[2] != 'A' || data[3] != 'L' ||
      (data[4] != '1' && data[4] != '2')) return false;

  const char action = static_cast<char>(data[5]);
  const char* valid = "ISFLRCJKUDZBb";
  bool found = false;
  for (const char* p = valid; *p; ++p) {
    if (*p == action) { found = true; break; }
  }
  if (!found) return false;

  out = {uint8_t(data[4] - '1'), data[6], action, size == 10, 0, 0, 0};
  if (size == 10) {
    out.forward = static_cast<int8_t>(data[7]);
    out.steer   = static_cast<int8_t>(data[8]);
    out.tilt    = static_cast<int8_t>(data[9]);
    if (out.forward < -100 || out.forward > 100 ||
        out.steer < -100 || out.steer > 100 ||
        out.tilt < -100 || out.tilt > 100) return false;
  }
  return true;
}
