# AstroLab Pico 2 W — Asynchronous BLE-to-USB game controller bridge

## Upload

1. Open `AstroLab_Pico_Game_Bridge.ino` with Arduino IDE; keep `ControllerProtocol.h` in the **same sketch folder**.
2. Select **Raspberry Pi Pico 2 W** in the Earle Philhower `rp2040` Arduino board package.
3. Tools → **IP/Bluetooth Stack**: enable Bluetooth. Tools → **Operating System**: **No OS**.
4. Upload and open Serial Monitor at **115200 baud**.
5. Power ESP32 P1 and ESP32 P2. Joystick, tilt, shake, flick and button inputs should become `REMOTE,P1,...` / `REMOTE,P2,...` messages.
6. Close Arduino Serial Monitor before starting the Python bridge; only one program can open Pico COM at a time.

## USB output contract

- `ASTROLAB,READY` on boot.
- `REMOTE,P1,STATE,<forward>,<steer>,<tilt>` (or P2), ~20 Hz while packets are fresh. Values -1.00, 0.00, +1.00 for current 7-byte controller firmware.
- `REMOTE,P1,SHAKE`
- `REMOTE,P1,UPWARD_FLICK`
- `REMOTE,P1,SELECT` (joystick button down)
- `REMOTE,P1,STATE,0.00,0.00,0.00` and `REMOTE,P1,DISCONNECTED` once after loss of packets.

## Important behavior and limitations

- Compatible with current ESP32 seven-byte manufacturer payload `FF FF 'A' 'L' player action sequence`, and future ten-byte snapshot packets described in `ControllerProtocol.h`.
- This uses asynchronous scanning (not `BLE.scan(1)`), with BTstack scan API `gap_set_scan_params(0,48,48,0)` matching the user's previously working receiver.
- **500 ms timeout changed to 1200 ms** to reduce false disconnects with the current advertisement cadence, at the expense of slower failure-to-neutral response. Tune after measuring packet arrival intervals.
- Duplicates and obviously older packets (modulo-256 sequence delta 0 or >=128) are ignored for input state changes and one-shot actions.
- The *first* packet after boot/reconnect sets the sequence baseline and can update directional axes, but cannot trigger an irreversible shake/flick/button event. This is conservative anti-replay behavior, not guaranteed delivery.
- BLE advertisements can be dropped. The current seven-byte ESP32 broadcasts changes rather than regularly refreshing current axes, so **a missed K or Z event can still leave stale steering**. Ten-byte periodic snapshots are the next ESP32 improvement, not something Pico alone can fix.
- Current controller snapshots, if added later, must specify how sequence numbers advance; sending all snapshots forever with the same seq would be deduplicated and not refresh state. Improve protocol explicitly on both ends before changing snapshots.
- This sketch is a **controller bridge**, not Pico-authoritative gameplay firmware: Python backend owns missions, collision handling and scoring. It intentionally ignores incoming USB commands.
- Firmware was not compiled on user's local Arduino-Pico 6.3.0 setup or hardware-tested. If compile errors mention Bluetooth APIs, compare with the previously working async receiver.

## Compile fix

`Pending` was moved from the `.ino` into `ControllerProtocol.h`. Arduino IDE may auto-generate function prototypes before seeing structures declared in `.ino`, causing a `Pending does not name a type` error. Keep the header in the same sketch folder. This has not been locally compiled against Arduino-Pico.
